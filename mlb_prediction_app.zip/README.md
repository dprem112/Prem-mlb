# MLB Prediction App

Streamlit app to predict MLB game outcomes using XGBoost.